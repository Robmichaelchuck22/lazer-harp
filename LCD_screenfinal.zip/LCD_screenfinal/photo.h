#ifndef PHOTO_H
#define PHOTO_H

#include <msp430.h>
#include <stdint.h>

void photo_init(void);
int photo_array_get(int channel);

#endif

