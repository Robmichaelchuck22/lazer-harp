#include <msp430.h>
#include "driverlib.h" // Required for the LCD
#include "myGpio.h" // Required for the LCD
#include "myClocks.h" // Required for the LCD
#include "myLcd.h" // Required for the LCD
#include "uart.h"
#include "photo.h"
#include "speaker.h"


int note;
int octave;
int volume= 1;

void main(void)
{


WDTCTL = WDTPW | WDTHOLD; // Stop WDT
initGPIO(); // Initializes General Purpose
// Inputs and Outputs for LCD
initClocks(); // Initialize clocks for LCD
myLCD_init(); // Prepares LCD to receive commands

uart_init();
photo_init();
speaker_init();

__bis_SR_register(GIE); //enable interrupts

note=1;
octave=1;

/*
while(1)
{
    uart_rx_check_queue(); //check the uart_rx queue for new commands
}

//space 1== note
//space 2== ' '
//space 3== octave
//space 4== ' '
//space 5== volume 0-9 changes every .366666666666666666v

*/






myLCD_showChar( 'N', 2 ); // Display 'a' in space 1

myLCD_showChar( 'O', 4 ); // Display 'a' in space 1

myLCD_showChar( 'V', 6 ); // Display 'a' in space 1


while(1)
{
    speaker_set_octave(octave);
    speaker_set_volume(note,volume);
    speaker_set_volume(2
                       ,volume);




   // __bis_SR_register(LPM4_bits + GIE);       // Enter LPM4 w/interrupt


switch(note)               //switch statement for 2nd 3rd and 4th bytes of input signal
      {
      case 1:
          myLCD_showChar( 'A', 1 ); // Display 'a' in space 1
          break;

      case 2:
          myLCD_showChar( 'B', 1 ); // Display 'b' in space 1
          break;

      case 3:
          myLCD_showChar( 'C', 1 ); // Display 'c' in space 1
          break;

      case 4:
          myLCD_showChar( 'D', 1 ); // Display 'd' in space 1
          break;

      case 5:
          myLCD_showChar( 'E', 1 ); // Display 'e' in space 1
          break;

      case 6:
          myLCD_showChar( 'F', 1 ); // Display 'f' in space 1
          break;

      case 7:
          myLCD_showChar( 'G', 1 ); // Display 'g' in space 1
          break;

      default:
          break;
      }




switch(octave)               //switch statement for 2nd 3rd and 4th bytes of input signal
      {
      case 1:

          myLCD_showChar( '1', 3 ); // Display 'a' in space 1
          break;

      case 2:

          myLCD_showChar( '2', 3 ); // Display 'b' in space 1
          break;

      default:
          break;
      }


switch(volume)               //switch statement for 2nd 3rd and 4th bytes of input signal
      {
      case 0:

          myLCD_showChar( '0', 5 ); // Display 'a' in space 1
          break;
      case 1:

          myLCD_showChar( '1', 5 ); // Display 'b' in space 1
          break;
      case 2:                       //4th input signal

          myLCD_showChar( '2', 5 ); // Display 'c' in space 1
          break;
      case 3:

          myLCD_showChar( '3', 5 ); // Display 'd' in space 1
          break;

      case 4:

           myLCD_showChar( '4', 5 ); // Display 'e' in space 1
           break;
      case 5:

           myLCD_showChar( '5', 5 ); // Display 'f' in space 1
           break;
      case 6:

           myLCD_showChar( '6', 5 ); // Display 'g' in space 1
           break;

      case 7:

           myLCD_showChar( '7', 5 ); // Display 'f' in space 1
           break;
      case 8:

           myLCD_showChar( '8', 5 ); // Display 'g' in space 1
           break;

      case 9:

           myLCD_showChar( '9', 5 ); // Display 'f' in space 1
           break;



      default:

          break;
      }


  PM5CTL0 &= ~LOCKLPM5;
  P1DIR |= BIT0;                            // Set P1.0 to output direction
  P9DIR |= BIT7;
  P1IE |=  BIT1;                            // P1.3 interrupt enabled
  P1IES |= BIT1;                            // P1.3 Hi/lo edge
  P1REN |= BIT1;                            // Enable Pull Up on SW2 (P1.3)
  P1IFG &= ~BIT1;                           // P1.3 IFG cleared
                                            //BIT3 on Port 1 can be used as Switch2




}

}

// Port 1 interrupt service routine
#if defined(__TI_COMPILER_VERSION__) || defined(__IAR_SYSTEMS_ICC__)
#pragma vector=PORT1_VECTOR
__interrupt void Port_1(void)
#elif defined(__GNUC__)
void __attribute__ ((interrupt(PORT1_VECTOR))) Port_1 (void)
#else
#error Compiler not supported!
#endif

{
/*
    if(note)
    {
        note++;
    }


    else
    {
        note=1;
    }
*/
    if(octave==1)
    {
        octave=2;
    }

    else
    {
        octave=1;
    }


  P1IFG &= ~BIT1;// P1.3 IFG cleared

}
/*
myLCD_showChar( space1, 1 ); // Display 'H' in space 1
myLCD_showChar( space2, 2 ); // Display 'E' in space 2
myLCD_showChar( space3, 3 ); // Display 'L' in space 3
myLCD_showChar( space4, 4 ); // Display 'L' in space 4
myLCD_showChar( space5, 5 ); // Display 'O' in space 5
myLCD_showChar( space6, 6 ); // Display blank space in space 6
}
*/

